'use strict';
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ander-'));
const tgCalls = [];
let tgMode = 'ok';
const tg = http.createServer((req, res) => {
  let b = ''; req.on('data', (d) => (b += d));
  req.on('end', () => {
    tgCalls.push({ url: req.url, body: JSON.parse(b) });
    if (tgMode === 'fail') { res.writeHead(400, { 'content-type': 'application/json' }); return res.end('{"ok":false,"description":"chat not found"}'); }
    res.writeHead(200, { 'content-type': 'application/json' }); res.end('{"ok":true}');
  });
});

(async () => {
  await new Promise((r) => tg.listen(0, r));
  Object.assign(process.env, {
    TG_API_BASE: `http://127.0.0.1:${tg.address().port}`, TG_BOT_TOKEN: '123:TESTTOKEN', TG_CHAT_ID: '111,222',
    ADMIN_TOKEN: 'secret', DATA_DIR: tmp, TRUST_PROXY: '1', ALLOWED_ORIGIN: 'https://user.github.io',
  });
  const app = require('./server.js');
  await new Promise((r) => app.listen(0, r));
  const base = `http://127.0.0.1:${app.address().port}`;
  let ip = '1.1.1.1', cookie = '';
  const hdr = () => ({ 'content-type': 'application/json', 'x-forwarded-for': ip, ...(cookie ? { cookie } : {}) });
  const j = async (p, o = {}) => { const r = await fetch(base + p, { ...o, headers: { ...hdr(), ...(o.headers || {}) } }); return { s: r.status, j: await r.json().catch(() => ({})), h: r.headers }; };
  const post = (p, b) => j(p, { method: 'POST', body: JSON.stringify(b) });
  const put = (p, b) => j(p, { method: 'PUT', body: JSON.stringify(b) });

  // public site content
  let r = await j('/api/site');
  assert.equal(r.s, 200); assert.equal(r.j.admin, false); assert.equal(r.j.menu.length, 33); assert.equal(r.j.rev, 1);
  assert.equal((await j('/api/site?rev=1')).j.unchanged, true);
  assert.ok(fs.existsSync(path.join(tmp, 'site.json')));

  // admin auth
  assert.equal((await put('/api/site', r.j)).s, 401, 'PUT without login');
  ip = '9.9.9.1';
  assert.equal((await post('/api/admin/login', { password: 'wrong' })).s, 403);
  r = await post('/api/admin/login', { password: 'secret' });
  assert.equal(r.s, 200);
  const sc = r.h.get('set-cookie'); assert.ok(/HttpOnly/.test(sc) && /SameSite=Strict/.test(sc));
  cookie = sc.split(';')[0];
  r = await j('/api/site'); assert.equal(r.j.admin, true);
  const full = r.j; delete full.admin;

  // edit: change texts, price, hide an item, add an item
  const edited = JSON.parse(JSON.stringify(full));
  edited.heroTitle = 'Новый заголовок'; edited.menu.find((m) => m.id === 'classic').p = 999;
  edited.menu.find((m) => m.id === 'ayran').on = false;
  edited.menu.push({ id: 'new-1', c: 'Десерты', e: '🍰', n: 'Баклава', d: 'Сладкая', p: 450, on: true });
  r = await put('/api/site', edited); assert.equal(r.s, 200); assert.equal(r.j.rev, 2);

  // validation
  const badPrice = JSON.parse(JSON.stringify(edited)); badPrice.menu[0].p = 1.5;
  assert.equal((await put('/api/site', badPrice)).s, 400);
  const badId = JSON.parse(JSON.stringify(edited)); badId.menu[0].id = 'Bad Id!';
  assert.equal((await put('/api/site', badId)).s, 400);
  const dup = JSON.parse(JSON.stringify(edited)); dup.menu[1].id = dup.menu[0].id;
  assert.equal((await put('/api/site', dup)).s, 400);
  const emptyName = JSON.parse(JSON.stringify(edited)); emptyName.menu[0].n = '   ';
  assert.equal((await put('/api/site', emptyName)).s, 400);
  assert.equal((await j('/api/site')).j.rev, 2, 'rejected edits do not change anything');

  // another visitor (no cookie) sees the change, but not hidden items
  const keep = cookie; cookie = ''; ip = '8.8.8.8';
  r = await j('/api/site?rev=1');
  assert.equal(r.j.heroTitle, 'Новый заголовок'); assert.equal(r.j.admin, false);
  assert.equal(r.j.menu.some((m) => m.id === 'ayran'), false); assert.equal(r.j.menu.some((m) => m.id === 'new-1'), true);
  assert.equal(r.j.menu.find((m) => m.id === 'classic').p, 999);
  assert.equal((await j('/api/site?rev=2')).j.unchanged, true);
  cookie = keep; assert.equal((await j('/api/site')).j.menu.some((m) => m.id === 'ayran'), true, 'admin still sees hidden item');

  // persisted across restart
  assert.equal(JSON.parse(fs.readFileSync(path.join(tmp, 'site.json'), 'utf8')).rev, 2);

  // reviews
  cookie = ''; ip = '1.1.1.1';
  r = await j('/api/reviews'); assert.equal(r.j.total, 0);
  r = await post('/api/reviews', { name: 'Анна', rating: 5, text: '<b>Вкусно</b>' }); assert.equal(r.s, 201);
  const id = r.j.id;
  ip = '2.2.2.2';
  assert.equal((await post('/api/reviews', { name: 'X', rating: 9, text: 'abc' })).s, 400);
  assert.equal((await post('/api/reviews', { name: '', rating: 5, text: 'abc' })).s, 400);
  assert.equal((await post('/api/reviews', { name: 'B', rating: 4, text: 'ok1' })).s, 201, 'third attempt still allowed');
  assert.equal((await post('/api/reviews', { name: 'C', rating: 4, text: 'ok2' })).s, 429, 'invalid attempts count toward the limit');
  r = await j('/api/reviews'); assert.equal(r.j.total, 2); assert.equal(r.j.items[1].text, '<b>Вкусно</b>');
  assert.equal((await j('/api/reviews/' + id, { method: 'DELETE' })).s, 401, 'delete requires admin');
  assert.equal((await j('/api/reviews/' + id, { method: 'DELETE', headers: { 'x-admin-token': 'secret' } })).s, 200);
  cookie = keep; ip = '3.3.3.4';
  const rid = (await j('/api/reviews')).j.items[0].id;
  assert.equal((await j('/api/reviews/' + rid, { method: 'DELETE' })).s, 200, 'delete via session cookie');
  assert.equal((await j('/api/reviews')).j.total, 0);

  // orders use the LIVE menu
  cookie = ''; ip = '4.4.4.4';
  const good = { name: 'Иван <i>', phone: '+375 29 123-45-67', address: 'ул. Тестовая, 1', comment: 'без лука & соли', items: [{ id: 'classic', qty: 2 }, { id: 'lemonade', qty: 1 }] };
  r = await post('/api/order', good);
  assert.equal(r.s, 200); assert.equal(r.j.total, 999 * 2 + 350, 'edited price is used');
  assert.equal(tgCalls.length, 2);
  const txt = tgCalls[0].body.text;
  assert.ok(txt.includes('Иван &lt;i&gt;') && txt.includes('без лука &amp; соли') && txt.includes('Итого: 23,48 BYN'), txt);
  ip = '5.5.5.5';
  assert.equal((await post('/api/order', { ...good, items: [{ id: 'ayran', qty: 1 }] })).s, 400, 'hidden item cannot be ordered');
  assert.equal((await post('/api/order', { ...good, items: [{ id: 'classic', qty: -1 }] })).s, 400);
  assert.equal((await post('/api/order', { ...good, phone: 'abc' })).s, 400);
  ip = '6.6.6.6'; tgMode = 'fail';
  assert.equal((await post('/api/order', good)).s, 502, 'telegram failure is reported');
  const log = fs.readFileSync(path.join(tmp, 'orders.jsonl'), 'utf8').trim().split('\n').map(JSON.parse);
  assert.equal(log.filter((l) => l.delivered).length, 1); assert.equal(log.filter((l) => !l.delivered).length, 1);

  // CORS + bearer token (GitHub Pages frontend on another origin)
  cookie = ''; ip = '10.0.0.1';
  const pf = await fetch(base + '/api/site', { method: 'OPTIONS', headers: { origin: 'https://user.github.io', 'access-control-request-method': 'PUT' } });
  assert.equal(pf.status, 204); assert.equal(pf.headers.get('access-control-allow-origin'), 'https://user.github.io');
  assert.ok(/authorization/.test(pf.headers.get('access-control-allow-headers')));
  const pf2 = await fetch(base + '/api/site', { headers: { origin: 'https://evil.example' } });
  assert.equal(pf2.headers.get('access-control-allow-origin'), null, 'foreign origin gets no CORS header');
  const lg = await post('/api/admin/login', { password: 'secret' }); assert.equal(lg.s, 200); assert.equal(lg.j.token.length, 48);
  const bearer = { authorization: 'Bearer ' + lg.j.token };
  assert.equal((await j('/api/site', { headers: bearer })).j.admin, true, 'bearer token works');
  assert.equal((await j('/api/site', { headers: { authorization: 'Bearer ' + 'a'.repeat(48) } })).j.admin, false);
  // logout invalidates session
  cookie = keep; ip = '7.7.7.7';
  assert.equal((await post('/api/admin/logout', {})).s, 200);
  assert.equal((await j('/api/site')).j.admin, false);

  // static + traversal
  cookie = '';
  let s = await fetch(base + '/'); assert.equal(s.status, 200); assert.ok((await s.text()).includes('id="spit"'));
  assert.equal((await fetch(base + '/..%2fserver.js')).status, 404);
  assert.equal((await fetch(base + '/%2e%2e/server.js')).status, 404);

  console.log('ALL OK');
  app.close(); tg.close(); process.exit(0);
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
