// Адрес бэкенда. Пусто = тот же домен, с которого открыт сайт.
// Для GitHub Pages впишите адрес сервера, например: "https://ander-doner.onrender.com"
window.ANDER_API = "";
